const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');

// Keep a global reference so the window isn't garbage-collected
let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1280,
    height: 800,
    minWidth:  800,
    minHeight: 560,
    title: 'لعبة الخلية',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#0f0a1e',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
    // Nice frameless-ish look
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    show: false, // show after ready-to-show to avoid flash
  });

  // Load the game
  mainWindow.loadFile(path.join(__dirname, 'game', 'index.html'));

  // Show only when fully rendered
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Remove default menu bar (keeps Alt menu on Windows)
  Menu.setApplicationMenu(null);

  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(createWindow);

// macOS: re-create window when dock icon is clicked
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// Quit when all windows are closed (except macOS)
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
