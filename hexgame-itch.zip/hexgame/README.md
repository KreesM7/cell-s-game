# لعبة الخلية — Build & Publish Guide

## What's in this folder

```
hexgame/
├── main.js              ← Electron entry point
├── package.json         ← Build config (Electron + electron-builder)
├── BUILD_WINDOWS.bat    ← One-click Windows build script
├── assets/
│   ├── icon.ico         ← Windows icon (multi-size)
│   └── icon.png         ← App icon (256×256)
└── game/
    ├── index.html       ← Game HTML
    ├── style.css        ← Game styles
    └── game.js          ← Game logic
```

---

## Step 1 — Install Node.js (one time only)

Download from **https://nodejs.org** → choose the **LTS** version → install.

---

## Step 2 — Build the EXE

**Windows:** Double-click `BUILD_WINDOWS.bat`

That's it. It will:
1. Install Electron automatically
2. Package your game into a Windows `.exe`
3. Output files to the `dist/` folder

**Or manually in terminal:**
```bash
npm install
npm run build:win
```

---

## Step 3 — What you get in `dist/`

| File | Use |
|------|-----|
| `لعبة الخلية Setup 1.0.0.exe` | Installer (recommended for itch.io) |
| `لعبة الخلية 1.0.0.exe` | Portable — runs without installing |

---

## Step 4 — Upload to itch.io

1. Go to **https://itch.io/game/new**
2. Fill in title, description, etc.
3. Under **Uploads**, click **Upload files**
4. Upload the `.exe` file from `dist/`
5. Set the file kind to **"Executable"**
6. Under **Kind of project** → select **"Downloadable"**
7. Check **"Windows"** as the platform
8. Hit **Save & view page** — done!

### Optional: Also upload the HTML version (plays in browser)
1. Zip `game/index.html` + `game/style.css` + `game/game.js` together
2. Upload that zip on the same page
3. Set kind to **"HTML"** and enable **"This file will be played in the browser"**
4. Now players can either play in-browser OR download the exe

---

## Test before uploading

Run locally without building:
```bash
npm start
```
This opens the game in an Electron window exactly as it will appear as an exe.

---

## Changing the app name / version

Edit `package.json`:
- `"productName"` → display name
- `"version"` → version number
- `"description"` → short description

---

## Building for other platforms

```bash
# macOS (must run on a Mac)
npm run build:mac

# Both Windows + Mac
npm run build:all
```
